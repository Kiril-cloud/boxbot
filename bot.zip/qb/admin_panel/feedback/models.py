from django.db import models


class Feedbacks(models.Model):
  user_id = models.TextField(verbose_name='user_id')
  Feedback = models.TextField(verbose_name="Отзыв")
  Teg = models.TextField(verbose_name="Тег")
  date = models.TextField(verbose_name="Дата")

  

  class Meta:
      verbose_name = 'Отзывы'
      verbose_name_plural = 'Отзывы'
