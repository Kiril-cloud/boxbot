from aiogram import types
from aiogram.types import callback_query
from loader import dp, bot
from keyboards.inline import step2, confirm, apruv
import asyncio



@dp.callback_query_handler(text='confirm')
async def step3(c):
    url = await bot.create_chat_invite_link(chat_id=-1001539512999, member_limit=1)
    await c.message.answer(f"""💬Ваша  одразавая ссылка на чат: {url["invite_link"]}
💭Ваша ссылка на канал
👋🏽 Не забудь поздороваться в чате со всеми

Напишите:
1. Как тебя зовут
2. Откуда ты
3. Каких результатов добился на марафоне

🤗 Делись настроением и инсайтами!
Добро пожаловать!""")
    await asyncio.sleep(300)
    await c.message.answer("""Мы всегда рады помочь:)
по любым вопросам касающийся обучения - твой куратор - консьерж 💁🏻‍♂️https://t.me/QBLbotsupport
Для начала работы, сообщи ему тайный код: """ + str(c.from_user.id))