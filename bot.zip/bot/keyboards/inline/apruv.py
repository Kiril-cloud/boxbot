from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

apruv = InlineKeyboardMarkup(row_width=1)
apr = InlineKeyboardButton("Подтвердить отзыв", callback_data='apruv')
apruv.add(apr)

confirm = InlineKeyboardMarkup(row_width=1)
st3 = InlineKeyboardButton("Согласен с условиями использования", callback_data='confirm')
confirm.add(st3)