from environs import Env


env = Env()
env.read_env()

BOT_TOKEN = "1751393324:AAENm8WxrTEPTZMEsbU7Igi1FeIDfUtwB8s"
ADMINS = ""
